// ==================== AUTHENTICATION MANAGER ====================

const Auth = {
    // Login user
    login(email, password) {
        const user = Storage.getUserByEmail(email);
        
        if (!user) {
            return { success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
        }

        const hashedPassword = Storage.hashPassword(password);
        
        if (user.password !== hashedPassword) {
            return { success: false, message: 'البريد الإلكتروني أو كلمة المرور غير صحيحة' };
        }

        // Set current user (without password)
        const userWithoutPassword = { ...user };
        delete userWithoutPassword.password;
        Storage.setCurrentUser(userWithoutPassword);

        return { success: true, user: userWithoutPassword };
    },

    // Register new user
    register(name, email, password, confirmPassword) {
        // Validation
        if (!name || !email || !password || !confirmPassword) {
            return { success: false, message: 'جميع الحقول مطلوبة' };
        }

        if (!Utils.validateEmail(email)) {
            return { success: false, message: 'البريد الإلكتروني غير صالح' };
        }

        if (password.length < 6) {
            return { success: false, message: 'كلمة المرور يجب أن تكون 6 أحرف على الأقل' };
        }

        if (password !== confirmPassword) {
            return { success: false, message: 'كلمات المرور غير متطابقة' };
        }

        // Create user
        const result = Storage.createUser({
            name,
            email,
            password,
            role: 'client'
        });

        if (!result.success) {
            return result;
        }

        // Auto login
        const userWithoutPassword = { ...result.user };
        delete userWithoutPassword.password;
        Storage.setCurrentUser(userWithoutPassword);

        return { success: true, user: userWithoutPassword };
    },

    // Logout
    logout() {
        Storage.clearCurrentUser();
        return { success: true };
    },

    // Get current user
    getCurrentUser() {
        return Storage.getCurrentUser();
    },

    // Check if user is logged in
    isLoggedIn() {
        return Storage.getCurrentUser() !== null;
    },

    // Check if user is admin
    isAdmin() {
        const user = Storage.getCurrentUser();
        return user && user.role === 'admin';
    },

    // Require authentication
    requireAuth() {
        if (!this.isLoggedIn()) {
            window.location.hash = '#/login';
            return false;
        }
        return true;
    },

    // Require admin
    requireAdmin() {
        if (!this.isLoggedIn()) {
            window.location.hash = '#/login';
            return false;
        }
        
        if (!this.isAdmin()) {
            Utils.showToast('ليس لديك صلاحية الوصول لهذه الصفحة', 'error');
            window.location.hash = '#/dashboard';
            return false;
        }
        
        return true;
    },

    // Update user profile
    updateProfile(updates) {
        const currentUser = this.getCurrentUser();
        
        if (!currentUser) {
            return { success: false, message: 'يجب تسجيل الدخول أولاً' };
        }

        const result = Storage.updateUser(currentUser.id, updates);
        
        if (result.success) {
            const userWithoutPassword = { ...result.user };
            delete userWithoutPassword.password;
            Storage.setCurrentUser(userWithoutPassword);
        }

        return result;
    },

    // Change password
    changePassword(currentPassword, newPassword, confirmPassword) {
        const currentUser = this.getCurrentUser();
        
        if (!currentUser) {
            return { success: false, message: 'يجب تسجيل الدخول أولاً' };
        }

        // Get user with password
        const user = Storage.getUserById(currentUser.id);
        const hashedCurrentPassword = Storage.hashPassword(currentPassword);
        
        if (user.password !== hashedCurrentPassword) {
            return { success: false, message: 'كلمة المرور الحالية غير صحيحة' };
        }

        if (newPassword.length < 6) {
            return { success: false, message: 'كلمة المرور الجديدة يجب أن تكون 6 أحرف على الأقل' };
        }

        if (newPassword !== confirmPassword) {
            return { success: false, message: 'كلمات المرور غير متطابقة' };
        }

        const hashedNewPassword = Storage.hashPassword(newPassword);
        const result = Storage.updateUser(currentUser.id, { password: hashedNewPassword });

        return result;
    }
};

// Export for use in other files
window.Auth = Auth;