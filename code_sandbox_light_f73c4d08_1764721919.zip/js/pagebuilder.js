// ==================== PAGE BUILDER ====================

const PageBuilder = {
    currentPage: null,
    
    // Render create page form
    renderCreatePage() {
        if (!Auth.requireAuth()) return;
        
        const currentUser = Auth.getCurrentUser();

        return `
            ${Components.navbar('dashboard')}
            <div class="dashboard-layout">
                ${Components.sidebar('pages')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">
                        <i class="fas fa-plus"></i> إنشاء صفحة جديدة
                    </h1>
                    
                    <div class="card">
                        <div class="card-body">
                            <form id="createPageForm" onsubmit="handleCreatePage(event)">
                                <div class="form-group">
                                    <label class="form-label">عنوان المنتج *</label>
                                    <input type="text" class="form-control" id="title" required>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">الرابط (Slug)</label>
                                    <input type="text" class="form-control" id="slug" placeholder="سيتم إنشاؤه تلقائياً">
                                    <small style="color: var(--text-secondary);">
                                        سيكون الرابط: ${window.location.origin}${window.location.pathname}#/page/your-slug
                                    </small>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">السعر (درهم) *</label>
                                    <input type="number" class="form-control" id="price" min="0" step="0.01" required>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">وصف المنتج *</label>
                                    <textarea class="form-control" id="description" rows="5" required></textarea>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">صور المنتج</label>
                                    <input type="file" class="form-control" id="images" multiple accept="image/*" onchange="handleImageUpload(event)">
                                    <small style="color: var(--text-secondary);">يمكنك اختيار عدة صور</small>
                                    <div id="imagePreview" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem; margin-top: 1rem;"></div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">اللون الرئيسي</label>
                                    <input type="color" class="form-control" id="primaryColor" value="#6366f1" style="height: 50px;">
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">لون الخلفية</label>
                                    <input type="color" class="form-control" id="backgroundColor" value="#ffffff" style="height: 50px;">
                                </div>
                                
                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> إنشاء الصفحة
                                    </button>
                                    <a href="#/dashboard/pages" class="btn btn-secondary">
                                        <i class="fas fa-times"></i> إلغاء
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
            </div>
        `;
    },

    // Render edit page form
    renderEditPage(pageId) {
        if (!Auth.requireAuth()) return;
        
        const page = Storage.getPageById(pageId);
        if (!page) {
            return Components.emptyState('fa-exclamation-triangle', 'الصفحة غير موجودة', '');
        }

        const currentUser = Auth.getCurrentUser();
        if (page.userId !== currentUser.id && currentUser.role !== 'admin') {
            Utils.showToast('ليس لديك صلاحية لتعديل هذه الصفحة', 'error');
            window.location.hash = '#/dashboard/pages';
            return;
        }

        return `
            ${Components.navbar('dashboard')}
            <div class="dashboard-layout">
                ${Components.sidebar('pages')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">
                        <i class="fas fa-edit"></i> تعديل الصفحة
                    </h1>
                    
                    <div class="card">
                        <div class="card-body">
                            <form id="editPageForm" onsubmit="handleEditPage(event, '${pageId}')">
                                <div class="form-group">
                                    <label class="form-label">عنوان المنتج *</label>
                                    <input type="text" class="form-control" id="title" value="${page.title}" required>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">الرابط (Slug)</label>
                                    <input type="text" class="form-control" id="slug" value="${page.slug}">
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">السعر (درهم) *</label>
                                    <input type="number" class="form-control" id="price" value="${page.price}" min="0" step="0.01" required>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">وصف المنتج *</label>
                                    <textarea class="form-control" id="description" rows="5" required>${page.content.description || ''}</textarea>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">صور المنتج</label>
                                    <input type="file" class="form-control" id="images" multiple accept="image/*" onchange="handleImageUpload(event)">
                                    <small style="color: var(--text-secondary);">يمكنك اختيار صور جديدة أو الاحتفاظ بالصور الحالية</small>
                                    <div id="imagePreview" style="display: grid; grid-template-columns: repeat(auto-fill, minmax(150px, 1fr)); gap: 1rem; margin-top: 1rem;">
                                        ${(page.images || []).map((img, index) => `
                                            <div style="position: relative;">
                                                <img src="${img}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px;">
                                                <button type="button" class="btn btn-danger" 
                                                    style="position: absolute; top: 5px; left: 5px; padding: 0.25rem 0.5rem;"
                                                    onclick="removeExistingImage(${index})">
                                                    <i class="fas fa-times"></i>
                                                </button>
                                            </div>
                                        `).join('')}
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">اللون الرئيسي</label>
                                    <input type="color" class="form-control" id="primaryColor" value="${page.content.primaryColor || '#6366f1'}" style="height: 50px;">
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">لون الخلفية</label>
                                    <input type="color" class="form-control" id="backgroundColor" value="${page.content.backgroundColor || '#ffffff'}" style="height: 50px;">
                                </div>
                                
                                <div class="form-group">
                                    <label class="form-label">حالة الصفحة</label>
                                    <select class="form-control" id="status">
                                        <option value="active" ${page.status === 'active' ? 'selected' : ''}>نشط</option>
                                        <option value="inactive" ${page.status === 'inactive' ? 'selected' : ''}>متوقف</option>
                                    </select>
                                </div>
                                
                                <div style="display: flex; gap: 1rem;">
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> حفظ التغييرات
                                    </button>
                                    <a href="#/dashboard/pages" class="btn btn-secondary">
                                        <i class="fas fa-times"></i> إلغاء
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </main>
            </div>
        `;
    },

    // Render public product page
    renderPublicPage(slug) {
        const page = Storage.getPageBySlug(slug);
        
        if (!page) {
            return `
                ${Components.navbar()}
                ${Components.emptyState('fa-exclamation-triangle', 'الصفحة غير موجودة', 'الصفحة التي تبحث عنها غير موجودة أو تم حذفها')}
            `;
        }

        // Track visit
        Storage.trackVisit(page.id);

        const images = page.images || [];
        const primaryColor = page.content.primaryColor || '#6366f1';
        const backgroundColor = page.content.backgroundColor || '#ffffff';
        const description = page.content.description || '';

        return `
            ${Components.navbar()}
            <div class="product-page" style="background-color: ${backgroundColor};">
                ${images.length > 0 ? `
                    <div class="product-header">
                        <img src="${images[0]}" alt="${page.title}" class="product-image" id="mainImage">
                    </div>
                    ${images.length > 1 ? `
                        <div class="product-gallery">
                            ${images.map((img, index) => `
                                <img src="${img}" alt="${page.title}" 
                                    class="gallery-thumb ${index === 0 ? 'active' : ''}" 
                                    onclick="changeMainImage('${img}', event)">
                            `).join('')}
                        </div>
                    ` : ''}
                ` : ''}
                
                <div class="product-info">
                    <h1 class="product-title">${page.title}</h1>
                    <div class="product-price" style="color: ${primaryColor};">
                        ${Utils.formatCurrency(page.price)}
                    </div>
                    <div class="product-description" style="white-space: pre-wrap;">
${description}
                    </div>
                    
                    ${Orders.renderOrderForm(page)}
                </div>
            </div>
        `;
    }
};

// Global handlers
let uploadedImages = [];
let existingImages = [];

window.handleImageUpload = async function(event) {
    const files = Array.from(event.target.files);
    const preview = document.getElementById('imagePreview');
    
    Utils.showLoading();
    
    for (const file of files) {
        try {
            // Compress image
            const compressed = await Utils.compressImage(file);
            const base64 = await Utils.imageToBase64(compressed);
            uploadedImages.push(base64);
            
            // Show preview
            const div = document.createElement('div');
            div.style.position = 'relative';
            div.innerHTML = `
                <img src="${base64}" style="width: 100%; height: 150px; object-fit: cover; border-radius: 8px;">
                <button type="button" class="btn btn-danger" 
                    style="position: absolute; top: 5px; left: 5px; padding: 0.25rem 0.5rem;"
                    onclick="removeUploadedImage(${uploadedImages.length - 1})">
                    <i class="fas fa-times"></i>
                </button>
            `;
            preview.appendChild(div);
        } catch (error) {
            console.error('Error uploading image:', error);
            Utils.showToast('خطأ في رفع الصورة', 'error');
        }
    }
    
    Utils.hideLoading();
};

window.removeUploadedImage = function(index) {
    uploadedImages.splice(index, 1);
    document.getElementById('imagePreview').children[index].remove();
};

window.removeExistingImage = function(index) {
    const page = PageBuilder.currentPage;
    if (page && page.images) {
        page.images.splice(index, 1);
        existingImages = page.images;
    }
    document.getElementById('imagePreview').children[index].remove();
};

window.handleCreatePage = function(event) {
    event.preventDefault();
    
    const currentUser = Auth.getCurrentUser();
    const title = document.getElementById('title').value;
    const slug = document.getElementById('slug').value || Utils.generateSlug(title);
    const price = parseFloat(document.getElementById('price').value);
    const description = document.getElementById('description').value;
    const primaryColor = document.getElementById('primaryColor').value;
    const backgroundColor = document.getElementById('backgroundColor').value;
    
    const result = Storage.createPage({
        userId: currentUser.id,
        title,
        slug,
        price,
        images: uploadedImages,
        content: {
            description,
            primaryColor,
            backgroundColor
        }
    });
    
    if (result.success) {
        Utils.showToast('تم إنشاء الصفحة بنجاح', 'success');
        uploadedImages = [];
        window.location.hash = '#/dashboard/pages';
    } else {
        Utils.showToast(result.message, 'error');
    }
};

window.handleEditPage = function(event, pageId) {
    event.preventDefault();
    
    const page = Storage.getPageById(pageId);
    const title = document.getElementById('title').value;
    const slug = document.getElementById('slug').value;
    const price = parseFloat(document.getElementById('price').value);
    const description = document.getElementById('description').value;
    const primaryColor = document.getElementById('primaryColor').value;
    const backgroundColor = document.getElementById('backgroundColor').value;
    const status = document.getElementById('status').value;
    
    // Combine existing and new images
    const allImages = [...(existingImages.length > 0 ? existingImages : page.images || []), ...uploadedImages];
    
    const result = Storage.updatePage(pageId, {
        title,
        slug,
        price,
        status,
        images: allImages,
        content: {
            description,
            primaryColor,
            backgroundColor
        }
    });
    
    if (result.success) {
        Utils.showToast('تم تحديث الصفحة بنجاح', 'success');
        uploadedImages = [];
        existingImages = [];
        window.location.hash = '#/dashboard/pages';
    } else {
        Utils.showToast(result.message, 'error');
    }
};

window.changeMainImage = function(src, event) {
    document.getElementById('mainImage').src = src;
    
    // Update active class
    document.querySelectorAll('.gallery-thumb').forEach(thumb => {
        thumb.classList.remove('active');
    });
    event.target.classList.add('active');
};

// Export
window.PageBuilder = PageBuilder;