// ==================== MAIN APPLICATION ====================

// Initialize application when DOM is ready
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 PageBuilder SaaS - Application Starting...');
    
    // Initialize storage
    Storage.init();
    console.log('✅ Storage initialized');
    
    // Initialize router
    Router.init();
    console.log('✅ Router initialized');
    
    console.log('✨ Application ready!');
    
    // Log current user info
    const currentUser = Auth.getCurrentUser();
    if (currentUser) {
        console.log(`👤 Logged in as: ${currentUser.name} (${currentUser.role})`);
    }
});

// Global error handler
window.addEventListener('error', (event) => {
    console.error('Application Error:', event.error);
    Utils.showToast('حدث خطأ في التطبيق', 'error');
});

// Handle unhandled promise rejections
window.addEventListener('unhandledrejection', (event) => {
    console.error('Unhandled Promise Rejection:', event.reason);
    Utils.showToast('حدث خطأ في التطبيق', 'error');
});

// Service Worker for offline support (optional)
if ('serviceWorker' in navigator) {
    // Uncomment to enable service worker
    // navigator.serviceWorker.register('/sw.js')
    //     .then(reg => console.log('Service Worker registered:', reg))
    //     .catch(err => console.log('Service Worker registration failed:', err));
}

// Export app info
window.APP_INFO = {
    name: 'PageBuilder SaaS',
    version: '1.0.0',
    author: 'PageBuilder Team',
    description: 'منصة إنشاء صفحات المنتجات الاحترافية'
};

console.log(`
██████╗  █████╗  ██████╗ ███████╗    ██████╗ ██╗   ██╗██╗██╗     ██████╗ ███████╗██████╗ 
██╔══██╗██╔══██╗██╔════╝ ██╔════╝    ██╔══██╗██║   ██║██║██║     ██╔══██╗██╔════╝██╔══██╗
██████╔╝███████║██║  ███╗█████╗      ██████╔╝██║   ██║██║██║     ██║  ██║█████╗  ██████╔╝
██╔═══╝ ██╔══██║██║   ██║██╔══╝      ██╔══██╗██║   ██║██║██║     ██║  ██║██╔══╝  ██╔══██╗
██║     ██║  ██║╚██████╔╝███████╗    ██████╔╝╚██████╔╝██║███████╗██████╔╝███████╗██║  ██║
╚═╝     ╚═╝  ╚═╝ ╚═════╝ ╚══════╝    ╚═════╝  ╚═════╝ ╚═╝╚══════╝╚═════╝ ╚══════╝╚═╝  ╚═╝
                                                                                          
Version: ${window.APP_INFO.version} | ${window.APP_INFO.description}
`);