// ==================== ANALYTICS MANAGER ====================

const Analytics = {
    // Get user statistics
    getUserStats(userId) {
        const pages = Storage.getPagesByUser(userId);
        const orders = Storage.getOrdersByUser(userId);
        
        const totalVisits = pages.reduce((sum, page) => sum + (page.visits || 0), 0);
        const totalOrders = orders.length;
        const completedOrders = orders.filter(o => o.status === 'completed').length;
        const pendingOrders = orders.filter(o => o.status === 'pending').length;
        const totalRevenue = orders
            .filter(o => o.status === 'completed')
            .reduce((sum, order) => sum + order.totalPrice, 0);
        
        const conversionRate = totalVisits > 0 ? ((totalOrders / totalVisits) * 100).toFixed(1) : 0;
        const completionRate = totalOrders > 0 ? ((completedOrders / totalOrders) * 100).toFixed(1) : 0;

        return {
            totalPages: pages.length,
            totalVisits,
            totalOrders,
            completedOrders,
            pendingOrders,
            totalRevenue,
            conversionRate,
            completionRate
        };
    },

    // Get admin statistics
    getAdminStats() {
        const users = Storage.getAllUsers();
        const pages = Storage.getAllPages();
        const orders = Storage.getAllOrders();
        
        const totalVisits = pages.reduce((sum, page) => sum + (page.visits || 0), 0);
        const totalOrders = orders.length;
        const completedOrders = orders.filter(o => o.status === 'completed').length;
        const totalRevenue = orders
            .filter(o => o.status === 'completed')
            .reduce((sum, order) => sum + order.totalPrice, 0);
        
        const conversionRate = totalVisits > 0 ? ((totalOrders / totalVisits) * 100).toFixed(1) : 0;

        return {
            totalUsers: users.length,
            totalPages: pages.length,
            totalVisits,
            totalOrders,
            completedOrders,
            totalRevenue,
            conversionRate
        };
    },

    // Get page performance
    getPagePerformance(pageId) {
        const page = Storage.getPageById(pageId);
        if (!page) return null;

        const orders = Storage.getOrdersByPage(pageId);
        const completedOrders = orders.filter(o => o.status === 'completed').length;
        const revenue = orders
            .filter(o => o.status === 'completed')
            .reduce((sum, order) => sum + order.totalPrice, 0);
        
        const conversionRate = page.visits > 0 ? ((orders.length / page.visits) * 100).toFixed(1) : 0;

        return {
            page,
            visits: page.visits || 0,
            orders: orders.length,
            completedOrders,
            revenue,
            conversionRate
        };
    },

    // Get top performing pages
    getTopPages(userId = null, limit = 5) {
        let pages = userId ? Storage.getPagesByUser(userId) : Storage.getAllPages();
        
        return pages
            .map(page => {
                const orders = Storage.getOrdersByPage(page.id);
                const revenue = orders
                    .filter(o => o.status === 'completed')
                    .reduce((sum, order) => sum + order.totalPrice, 0);
                
                return {
                    ...page,
                    totalOrders: orders.length,
                    revenue,
                    conversionRate: page.visits > 0 ? ((orders.length / page.visits) * 100).toFixed(1) : 0
                };
            })
            .sort((a, b) => b.revenue - a.revenue)
            .slice(0, limit);
    },

    // Get recent orders
    getRecentOrders(userId = null, limit = 10) {
        let orders = userId ? Storage.getOrdersByUser(userId) : Storage.getAllOrders();
        
        return orders
            .sort((a, b) => b.createdAt - a.createdAt)
            .slice(0, limit)
            .map(order => {
                const page = Storage.getPageById(order.pageId);
                return {
                    ...order,
                    pageName: page ? page.title : 'صفحة محذوفة'
                };
            });
    },

    // Get orders by status
    getOrdersByStatus(status, userId = null) {
        let orders = userId ? Storage.getOrdersByUser(userId) : Storage.getAllOrders();
        return orders.filter(o => o.status === status);
    },

    // Get revenue by period
    getRevenueByPeriod(userId = null, days = 7) {
        let orders = userId ? Storage.getOrdersByUser(userId) : Storage.getAllOrders();
        const completedOrders = orders.filter(o => o.status === 'completed');
        
        const result = [];
        for (let i = days - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            date.setHours(0, 0, 0, 0);
            
            const nextDate = new Date(date);
            nextDate.setDate(nextDate.getDate() + 1);
            
            const dayOrders = completedOrders.filter(o => {
                const orderDate = new Date(o.createdAt);
                return orderDate >= date && orderDate < nextDate;
            });
            
            const revenue = dayOrders.reduce((sum, order) => sum + order.totalPrice, 0);
            
            result.push({
                date: date.toLocaleDateString('ar-MA', { month: 'short', day: 'numeric' }),
                revenue,
                orders: dayOrders.length
            });
        }
        
        return result;
    },

    // Get visits by period
    getVisitsByPeriod(pageId, days = 7) {
        return Storage.getVisitsByPage(pageId, days);
    },

    // Render analytics chart (simple bar chart)
    renderSimpleChart(data, labelKey, valueKey, title) {
        const maxValue = Math.max(...data.map(d => d[valueKey]));
        
        return `
            <div style="background: white; padding: 1.5rem; border-radius: 12px; box-shadow: var(--shadow-md);">
                <h3 style="font-size: 1.25rem; font-weight: 700; margin-bottom: 1.5rem;">
                    ${title}
                </h3>
                <div style="display: flex; flex-direction: column; gap: 0.75rem;">
                    ${data.map(item => {
                        const percentage = maxValue > 0 ? (item[valueKey] / maxValue * 100) : 0;
                        return `
                            <div>
                                <div style="display: flex; justify-content: space-between; margin-bottom: 0.25rem; font-size: 0.9rem;">
                                    <span style="font-weight: 600;">${item[labelKey]}</span>
                                    <span style="color: var(--primary); font-weight: 700;">
                                        ${valueKey === 'revenue' ? Utils.formatCurrency(item[valueKey]) : Utils.formatNumber(item[valueKey])}
                                    </span>
                                </div>
                                <div style="background: var(--bg-tertiary); height: 8px; border-radius: 4px; overflow: hidden;">
                                    <div style="background: linear-gradient(90deg, var(--primary), var(--primary-light)); height: 100%; width: ${percentage}%; transition: width 0.3s ease;"></div>
                                </div>
                            </div>
                        `;
                    }).join('')}
                </div>
            </div>
        `;
    }
};

// Export
window.Analytics = Analytics;