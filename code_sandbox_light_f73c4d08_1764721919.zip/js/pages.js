// ==================== PAGES MANAGER ====================

const Pages = {
    // Render home page
    renderHome() {
        return `
            ${Components.navbar()}
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; display: flex; align-items: center;">
                <div class="container">
                    <div style="text-align: center; color: white; padding: 4rem 1rem;">
                        <div style="font-size: 4rem; margin-bottom: 1rem;">
                            <i class="fas fa-layer-group"></i>
                        </div>
                        <h1 style="font-size: 3rem; font-weight: 800; margin-bottom: 1rem;">
                            PageBuilder SaaS
                        </h1>
                        <p style="font-size: 1.25rem; margin-bottom: 2rem; opacity: 0.9;">
                            منصة احترافية لإنشاء صفحات منتجات جذابة بسهولة
                        </p>
                        <div style="display: flex; gap: 1rem; justify-content: center; flex-wrap: wrap;">
                            <a href="#/register" class="btn" style="background: white; color: var(--primary); font-size: 1.1rem; padding: 1rem 2rem;">
                                <i class="fas fa-rocket"></i> ابدأ مجاناً
                            </a>
                            <a href="#/login" class="btn btn-outline" style="border-color: white; color: white; font-size: 1.1rem; padding: 1rem 2rem;">
                                <i class="fas fa-sign-in-alt"></i> تسجيل الدخول
                            </a>
                        </div>
                    </div>
                    
                    <div style="margin-top: 4rem;">
                        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 2rem;">
                            <div style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); padding: 2rem; border-radius: 12px; text-align: center;">
                                <div style="font-size: 3rem; margin-bottom: 1rem;">
                                    <i class="fas fa-paint-brush"></i>
                                </div>
                                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">محرر بصري</h3>
                                <p style="opacity: 0.9;">أنشئ صفحات جذابة بدون أي خبرة برمجية</p>
                            </div>
                            <div style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); padding: 2rem; border-radius: 12px; text-align: center;">
                                <div style="font-size: 3rem; margin-bottom: 1rem;">
                                    <i class="fas fa-chart-line"></i>
                                </div>
                                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">إحصائيات مفصلة</h3>
                                <p style="opacity: 0.9;">تتبع الزيارات والطلبات ومعدل التحويل</p>
                            </div>
                            <div style="background: rgba(255, 255, 255, 0.1); backdrop-filter: blur(10px); padding: 2rem; border-radius: 12px; text-align: center;">
                                <div style="font-size: 3rem; margin-bottom: 1rem;">
                                    <i class="fab fa-whatsapp"></i>
                                </div>
                                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">تكامل واتساب</h3>
                                <p style="opacity: 0.9;">تواصل مع عملائك مباشرة عبر واتساب</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    },

    // Render login page
    renderLogin() {
        return `
            <div class="auth-container">
                <div class="auth-card">
                    <div class="auth-header">
                        <div class="auth-logo">
                            <i class="fas fa-layer-group"></i>
                        </div>
                        <h2 class="auth-title">تسجيل الدخول</h2>
                        <p class="auth-subtitle">مرحباً بك مجدداً</p>
                    </div>
                    <form id="loginForm" class="auth-form" onsubmit="handleLogin(event)">
                        <div class="form-group">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" class="form-control" id="email" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" class="form-control" id="password" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-sign-in-alt"></i> تسجيل الدخول
                        </button>
                    </form>
                    <div class="auth-footer">
                        ليس لديك حساب؟ <a href="#/register" class="auth-link">سجل الآن</a>
                    </div>
                    <div style="margin-top: 1rem; padding-top: 1rem; border-top: 1px solid var(--border-color); font-size: 0.85rem; color: var(--text-secondary);">
                        <strong>حساب تجريبي:</strong><br>
                        البريد: mohamef@gmail.com<br>
                        كلمة المرور: 363839
                    </div>
                </div>
            </div>
        `;
    },

    // Render register page
    renderRegister() {
        return `
            <div class="auth-container">
                <div class="auth-card">
                    <div class="auth-header">
                        <div class="auth-logo">
                            <i class="fas fa-user-plus"></i>
                        </div>
                        <h2 class="auth-title">إنشاء حساب جديد</h2>
                        <p class="auth-subtitle">ابدأ رحلتك معنا</p>
                    </div>
                    <form id="registerForm" class="auth-form" onsubmit="handleRegister(event)">
                        <div class="form-group">
                            <label class="form-label">الاسم الكامل</label>
                            <input type="text" class="form-control" id="name" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">البريد الإلكتروني</label>
                            <input type="email" class="form-control" id="email" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">كلمة المرور</label>
                            <input type="password" class="form-control" id="password" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">تأكيد كلمة المرور</label>
                            <input type="password" class="form-control" id="confirmPassword" required>
                        </div>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-user-plus"></i> إنشاء حساب
                        </button>
                    </form>
                    <div class="auth-footer">
                        لديك حساب بالفعل؟ <a href="#/login" class="auth-link">سجل الدخول</a>
                    </div>
                </div>
            </div>
        `;
    },

    // Render dashboard overview
    renderDashboard() {
        if (!Auth.requireAuth()) return;
        
        const currentUser = Auth.getCurrentUser();
        const userPages = Storage.getPagesByUser(currentUser.id);
        const userOrders = Storage.getOrdersByUser(currentUser.id);
        
        const totalVisits = userPages.reduce((sum, page) => sum + (page.visits || 0), 0);
        const totalOrders = userOrders.length;
        const totalRevenue = userOrders
            .filter(o => o.status === 'completed')
            .reduce((sum, order) => sum + order.totalPrice, 0);
        
        const conversionRate = totalVisits > 0 ? ((totalOrders / totalVisits) * 100).toFixed(1) : 0;

        return `
            ${Components.navbar('dashboard')}
            <div class="dashboard-layout">
                ${Components.sidebar('overview')}
                <main class="main-content">
                    <div style="margin-bottom: 2rem;">
                        <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 0.5rem;">
                            مرحباً، ${currentUser.name}
                        </h1>
                        <p style="color: var(--text-secondary);">إليك نظرة عامة على أداء صفحاتك</p>
                    </div>
                    
                    <div class="stats-grid">
                        ${Components.statCard('fa-file', Utils.formatNumber(userPages.length), 'صفحاتي', 'success')}
                        ${Components.statCard('fa-eye', Utils.formatNumber(totalVisits), 'إجمالي الزيارات', 'info')}
                        ${Components.statCard('fa-shopping-cart', Utils.formatNumber(totalOrders), 'إجمالي الطلبات', 'warning')}
                        ${Components.statCard('fa-chart-line', conversionRate + '%', 'معدل التحويل', '')}
                    </div>

                    <div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: var(--shadow-md); margin-bottom: 2rem;">
                        <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 1rem;">
                            <i class="fas fa-coins"></i> الإيرادات
                        </h2>
                        <div style="font-size: 2.5rem; font-weight: 800; color: var(--success);">
                            ${Utils.formatCurrency(totalRevenue)}
                        </div>
                        <p style="color: var(--text-secondary);">من الطلبات المكتملة</p>
                    </div>

                    <div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: var(--shadow-md);">
                        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 1.5rem;">
                            <h2 style="font-size: 1.5rem; font-weight: 700;">
                                <i class="fas fa-file"></i> صفحاتي
                            </h2>
                            <a href="#/dashboard/pages/create" class="btn btn-primary">
                                <i class="fas fa-plus"></i> صفحة جديدة
                            </a>
                        </div>
                        
                        ${userPages.length > 0 ? `
                            <div style="display: grid; gap: 1.5rem;">
                                ${userPages.slice(0, 3).map(page => Components.pageCard(page)).join('')}
                            </div>
                            ${userPages.length > 3 ? `
                                <div style="text-align: center; margin-top: 1.5rem;">
                                    <a href="#/dashboard/pages" class="btn btn-secondary">
                                        عرض جميع الصفحات
                                    </a>
                                </div>
                            ` : ''}
                        ` : Components.emptyState(
                            'fa-file',
                            'لا توجد صفحات بعد',
                            'ابدأ بإنشاء صفحة منتج جديدة',
                            '<i class="fas fa-plus"></i> صفحة جديدة',
                            "window.location.hash='#/dashboard/pages/create'"
                        )}
                    </div>
                </main>
            </div>
        `;
    },

    // Render user pages list
    renderUserPages() {
        if (!Auth.requireAuth()) return;
        
        const currentUser = Auth.getCurrentUser();
        const userPages = Storage.getPagesByUser(currentUser.id);

        return `
            ${Components.navbar('dashboard')}
            <div class="dashboard-layout">
                ${Components.sidebar('pages')}
                <main class="main-content">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
                        <h1 style="font-size: 2rem; font-weight: 800;">صفحاتي</h1>
                        <a href="#/dashboard/pages/create" class="btn btn-primary">
                            <i class="fas fa-plus"></i> صفحة جديدة
                        </a>
                    </div>
                    
                    ${userPages.length > 0 ? `
                        <div style="display: grid; gap: 1.5rem;">
                            ${userPages.map(page => Components.pageCard(page)).join('')}
                        </div>
                    ` : Components.emptyState(
                        'fa-file',
                        'لا توجد صفحات بعد',
                        'ابدأ بإنشاء صفحة منتج جديدة',
                        '<i class="fas fa-plus"></i> صفحة جديدة',
                        "window.location.hash='#/dashboard/pages/create'"
                    )}
                </main>
            </div>
        `;
    },

    // Render user orders
    renderUserOrders() {
        if (!Auth.requireAuth()) return;
        
        const currentUser = Auth.getCurrentUser();
        const userOrders = Storage.getOrdersByUser(currentUser.id);

        return `
            ${Components.navbar('dashboard')}
            <div class="dashboard-layout">
                ${Components.sidebar('orders')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">طلباتي</h1>
                    
                    ${userOrders.length > 0 ? `
                        <div style="display: grid; gap: 1.5rem;">
                            ${userOrders.sort((a, b) => b.createdAt - a.createdAt).map(order => Components.orderCard(order)).join('')}
                        </div>
                    ` : Components.emptyState(
                        'fa-shopping-cart',
                        'لا توجد طلبات بعد',
                        'ستظهر الطلبات هنا عندما يقوم الزوار بطلب منتجاتك'
                    )}
                </main>
            </div>
        `;
    },

    // Render user settings
    renderUserSettings() {
        if (!Auth.requireAuth()) return;
        
        const currentUser = Auth.getCurrentUser();

        return `
            ${Components.navbar('dashboard')}
            <div class="dashboard-layout">
                ${Components.sidebar('settings')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">الإعدادات</h1>
                    
                    <div style="display: grid; gap: 2rem;">
                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-user"></i> معلومات الحساب</h3>
                            </div>
                            <div class="card-body">
                                <form id="profileForm" onsubmit="handleUpdateProfile(event)">
                                    <div class="form-group">
                                        <label class="form-label">الاسم الكامل</label>
                                        <input type="text" class="form-control" id="name" value="${currentUser.name}" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">البريد الإلكتروني</label>
                                        <input type="email" class="form-control" value="${currentUser.email}" disabled>
                                        <small style="color: var(--text-secondary);">لا يمكن تغيير البريد الإلكتروني</small>
                                    </div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-save"></i> حفظ التغييرات
                                    </button>
                                </form>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-header">
                                <h3><i class="fas fa-lock"></i> تغيير كلمة المرور</h3>
                            </div>
                            <div class="card-body">
                                <form id="passwordForm" onsubmit="handleChangePassword(event)">
                                    <div class="form-group">
                                        <label class="form-label">كلمة المرور الحالية</label>
                                        <input type="password" class="form-control" id="currentPassword" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">كلمة المرور الجديدة</label>
                                        <input type="password" class="form-control" id="newPassword" required>
                                    </div>
                                    <div class="form-group">
                                        <label class="form-label">تأكيد كلمة المرور الجديدة</label>
                                        <input type="password" class="form-control" id="confirmNewPassword" required>
                                    </div>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="fas fa-key"></i> تغيير كلمة المرور
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        `;
    }
};

// Global form handlers
window.handleLogin = function(event) {
    event.preventDefault();
    
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    
    const result = Auth.login(email, password);
    
    if (result.success) {
        Utils.showToast('تم تسجيل الدخول بنجاح', 'success');
        window.location.hash = '#/dashboard';
    } else {
        Utils.showToast(result.message, 'error');
    }
};

window.handleRegister = function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    const result = Auth.register(name, email, password, confirmPassword);
    
    if (result.success) {
        Utils.showToast('تم إنشاء الحساب بنجاح', 'success');
        window.location.hash = '#/dashboard';
    } else {
        Utils.showToast(result.message, 'error');
    }
};

window.handleUpdateProfile = function(event) {
    event.preventDefault();
    
    const name = document.getElementById('name').value;
    
    const result = Auth.updateProfile({ name });
    
    if (result.success) {
        Utils.showToast('تم تحديث الملف الشخصي بنجاح', 'success');
    } else {
        Utils.showToast(result.message, 'error');
    }
};

window.handleChangePassword = function(event) {
    event.preventDefault();
    
    const currentPassword = document.getElementById('currentPassword').value;
    const newPassword = document.getElementById('newPassword').value;
    const confirmNewPassword = document.getElementById('confirmNewPassword').value;
    
    const result = Auth.changePassword(currentPassword, newPassword, confirmNewPassword);
    
    if (result.success) {
        Utils.showToast('تم تغيير كلمة المرور بنجاح', 'success');
        event.target.reset();
    } else {
        Utils.showToast(result.message, 'error');
    }
};

// Export
window.Pages = Pages;