// ==================== LOCAL STORAGE MANAGER ====================

const Storage = {
    // Keys
    KEYS: {
        USERS: 'pagebuilder_users',
        PAGES: 'pagebuilder_pages',
        ORDERS: 'pagebuilder_orders',
        CURRENT_USER: 'pagebuilder_current_user',
        VISITS: 'pagebuilder_visits'
    },

    // Initialize storage with default admin user
    init() {
        if (!this.get(this.KEYS.USERS)) {
            const defaultAdmin = {
                id: Utils.generateId(),
                email: 'mohamef@gmail.com',
                password: this.hashPassword('363839'),
                name: 'Mohamed Admin',
                role: 'admin',
                createdAt: Date.now()
            };
            this.set(this.KEYS.USERS, [defaultAdmin]);
        }

        if (!this.get(this.KEYS.PAGES)) {
            this.set(this.KEYS.PAGES, []);
        }

        if (!this.get(this.KEYS.ORDERS)) {
            this.set(this.KEYS.ORDERS, []);
        }

        if (!this.get(this.KEYS.VISITS)) {
            this.set(this.KEYS.VISITS, {});
        }
    },

    // Basic operations
    get(key) {
        try {
            const data = localStorage.getItem(key);
            return data ? JSON.parse(data) : null;
        } catch (error) {
            console.error('Storage get error:', error);
            return null;
        }
    },

    set(key, value) {
        try {
            localStorage.setItem(key, JSON.stringify(value));
            return true;
        } catch (error) {
            console.error('Storage set error:', error);
            return false;
        }
    },

    remove(key) {
        try {
            localStorage.removeItem(key);
            return true;
        } catch (error) {
            console.error('Storage remove error:', error);
            return false;
        }
    },

    clear() {
        try {
            localStorage.clear();
            return true;
        } catch (error) {
            console.error('Storage clear error:', error);
            return false;
        }
    },

    // Hash password (simple hash for demo - use bcrypt in production)
    hashPassword(password) {
        let hash = 0;
        for (let i = 0; i < password.length; i++) {
            const char = password.charCodeAt(i);
            hash = ((hash << 5) - hash) + char;
            hash = hash & hash;
        }
        return hash.toString();
    },

    // User operations
    createUser(userData) {
        const users = this.get(this.KEYS.USERS) || [];
        
        // Check if email exists
        if (users.some(u => u.email === userData.email)) {
            return { success: false, message: 'البريد الإلكتروني مستخدم بالفعل' };
        }

        const newUser = {
            id: Utils.generateId(),
            email: userData.email,
            password: this.hashPassword(userData.password),
            name: userData.name,
            role: userData.role || 'client',
            createdAt: Date.now()
        };

        users.push(newUser);
        this.set(this.KEYS.USERS, users);

        return { success: true, user: newUser };
    },

    getUserByEmail(email) {
        const users = this.get(this.KEYS.USERS) || [];
        return users.find(u => u.email === email);
    },

    getUserById(id) {
        const users = this.get(this.KEYS.USERS) || [];
        return users.find(u => u.id === id);
    },

    getAllUsers() {
        return this.get(this.KEYS.USERS) || [];
    },

    updateUser(userId, updates) {
        const users = this.get(this.KEYS.USERS) || [];
        const index = users.findIndex(u => u.id === userId);
        
        if (index === -1) {
            return { success: false, message: 'المستخدم غير موجود' };
        }

        users[index] = { ...users[index], ...updates };
        this.set(this.KEYS.USERS, users);

        return { success: true, user: users[index] };
    },

    deleteUser(userId) {
        const users = this.get(this.KEYS.USERS) || [];
        const filtered = users.filter(u => u.id !== userId);
        this.set(this.KEYS.USERS, filtered);
        
        return { success: true };
    },

    // Current user operations
    setCurrentUser(user) {
        const userWithoutPassword = { ...user };
        delete userWithoutPassword.password;
        this.set(this.KEYS.CURRENT_USER, userWithoutPassword);
    },

    getCurrentUser() {
        return this.get(this.KEYS.CURRENT_USER);
    },

    clearCurrentUser() {
        this.remove(this.KEYS.CURRENT_USER);
    },

    // Page operations
    createPage(pageData) {
        const pages = this.get(this.KEYS.PAGES) || [];
        
        const newPage = {
            id: Utils.generateId(),
            userId: pageData.userId,
            title: pageData.title,
            slug: pageData.slug || Utils.generateSlug(pageData.title),
            content: pageData.content || {},
            images: pageData.images || [],
            price: pageData.price || 0,
            status: 'active',
            visits: 0,
            orders: 0,
            createdAt: Date.now(),
            updatedAt: Date.now()
        };

        pages.push(newPage);
        this.set(this.KEYS.PAGES, pages);

        return { success: true, page: newPage };
    },

    getPageById(id) {
        const pages = this.get(this.KEYS.PAGES) || [];
        return pages.find(p => p.id === id);
    },

    getPageBySlug(slug) {
        const pages = this.get(this.KEYS.PAGES) || [];
        return pages.find(p => p.slug === slug);
    },

    getPagesByUser(userId) {
        const pages = this.get(this.KEYS.PAGES) || [];
        return pages.filter(p => p.userId === userId);
    },

    getAllPages() {
        return this.get(this.KEYS.PAGES) || [];
    },

    updatePage(pageId, updates) {
        const pages = this.get(this.KEYS.PAGES) || [];
        const index = pages.findIndex(p => p.id === pageId);
        
        if (index === -1) {
            return { success: false, message: 'الصفحة غير موجودة' };
        }

        pages[index] = { 
            ...pages[index], 
            ...updates, 
            updatedAt: Date.now() 
        };
        this.set(this.KEYS.PAGES, pages);

        return { success: true, page: pages[index] };
    },

    deletePage(pageId) {
        const pages = this.get(this.KEYS.PAGES) || [];
        const filtered = pages.filter(p => p.id !== pageId);
        this.set(this.KEYS.PAGES, filtered);
        
        return { success: true };
    },

    incrementPageVisits(pageId) {
        const pages = this.get(this.KEYS.PAGES) || [];
        const index = pages.findIndex(p => p.id === pageId);
        
        if (index !== -1) {
            pages[index].visits = (pages[index].visits || 0) + 1;
            this.set(this.KEYS.PAGES, pages);
        }
    },

    incrementPageOrders(pageId) {
        const pages = this.get(this.KEYS.PAGES) || [];
        const index = pages.findIndex(p => p.id === pageId);
        
        if (index !== -1) {
            pages[index].orders = (pages[index].orders || 0) + 1;
            this.set(this.KEYS.PAGES, pages);
        }
    },

    // Order operations
    createOrder(orderData) {
        const orders = this.get(this.KEYS.ORDERS) || [];
        
        const newOrder = {
            id: Utils.generateId(),
            pageId: orderData.pageId,
            userId: orderData.userId,
            customerName: orderData.customerName,
            customerPhone: orderData.customerPhone,
            customerAddress: orderData.customerAddress,
            notes: orderData.notes || '',
            quantity: orderData.quantity || 1,
            totalPrice: orderData.totalPrice,
            status: 'pending',
            createdAt: Date.now(),
            updatedAt: Date.now()
        };

        orders.push(newOrder);
        this.set(this.KEYS.ORDERS, orders);

        // Increment page orders count
        this.incrementPageOrders(orderData.pageId);

        return { success: true, order: newOrder };
    },

    getOrderById(id) {
        const orders = this.get(this.KEYS.ORDERS) || [];
        return orders.find(o => o.id === id);
    },

    getOrdersByUser(userId) {
        const orders = this.get(this.KEYS.ORDERS) || [];
        return orders.filter(o => o.userId === userId);
    },

    getOrdersByPage(pageId) {
        const orders = this.get(this.KEYS.ORDERS) || [];
        return orders.filter(o => o.pageId === pageId);
    },

    getAllOrders() {
        return this.get(this.KEYS.ORDERS) || [];
    },

    updateOrder(orderId, updates) {
        const orders = this.get(this.KEYS.ORDERS) || [];
        const index = orders.findIndex(o => o.id === orderId);
        
        if (index === -1) {
            return { success: false, message: 'الطلب غير موجود' };
        }

        orders[index] = { 
            ...orders[index], 
            ...updates, 
            updatedAt: Date.now() 
        };
        this.set(this.KEYS.ORDERS, orders);

        return { success: true, order: orders[index] };
    },

    deleteOrder(orderId) {
        const orders = this.get(this.KEYS.ORDERS) || [];
        const filtered = orders.filter(o => o.id !== orderId);
        this.set(this.KEYS.ORDERS, filtered);
        
        return { success: true };
    },

    // Visit tracking
    trackVisit(pageId) {
        const visits = this.get(this.KEYS.VISITS) || {};
        const today = new Date().toDateString();
        
        if (!visits[pageId]) {
            visits[pageId] = {};
        }
        
        if (!visits[pageId][today]) {
            visits[pageId][today] = 0;
        }
        
        visits[pageId][today]++;
        this.set(this.KEYS.VISITS, visits);
        
        // Also increment total page visits
        this.incrementPageVisits(pageId);
    },

    getVisitsByPage(pageId, days = 7) {
        const visits = this.get(this.KEYS.VISITS) || {};
        const pageVisits = visits[pageId] || {};
        
        const result = [];
        for (let i = days - 1; i >= 0; i--) {
            const date = new Date();
            date.setDate(date.getDate() - i);
            const dateStr = date.toDateString();
            result.push({
                date: dateStr,
                count: pageVisits[dateStr] || 0
            });
        }
        
        return result;
    }
};

// Initialize storage
Storage.init();

// Export for use in other files
window.Storage = Storage;