// ==================== ROUTER ====================

const Router = {
    routes: {},
    
    // Add route
    add(path, handler) {
        this.routes[path] = handler;
    },
    
    // Navigate to route
    navigate(hash) {
        const path = hash.replace('#', '') || '/';
        
        // Find matching route
        let handler = null;
        let params = {};
        
        // Exact match
        if (this.routes[path]) {
            handler = this.routes[path];
        } else {
            // Pattern matching
            for (const route in this.routes) {
                const pattern = this.createPattern(route);
                const match = path.match(pattern);
                
                if (match) {
                    handler = this.routes[route];
                    params = this.extractParams(route, path);
                    break;
                }
            }
        }
        
        // Execute handler
        if (handler) {
            const content = handler(params);
            document.getElementById('app').innerHTML = content;
            window.scrollTo(0, 0);
        } else {
            this.notFound();
        }
    },
    
    // Create regex pattern from route
    createPattern(route) {
        const pattern = route
            .replace(/\//g, '\\/')
            .replace(/:(\w+)/g, '([^/]+)');
        return new RegExp(`^${pattern}$`);
    },
    
    // Extract params from route
    extractParams(route, path) {
        const params = {};
        const routeParts = route.split('/');
        const pathParts = path.split('/');
        
        routeParts.forEach((part, index) => {
            if (part.startsWith(':')) {
                const paramName = part.slice(1);
                params[paramName] = pathParts[index];
            }
        });
        
        return params;
    },
    
    // 404 handler
    notFound() {
        document.getElementById('app').innerHTML = `
            ${Components.navbar()}
            <div style="min-height: 80vh; display: flex; align-items: center; justify-content: center;">
                ${Components.emptyState(
                    'fa-exclamation-triangle',
                    'الصفحة غير موجودة',
                    'الصفحة التي تبحث عنها غير موجودة',
                    '<i class="fas fa-home"></i> العودة للرئيسية',
                    "window.location.hash='#/'"
                )}
            </div>
        `;
    },
    
    // Initialize router
    init() {
        // Define routes
        this.add('/', () => Pages.renderHome());
        this.add('/login', () => Pages.renderLogin());
        this.add('/register', () => Pages.renderRegister());
        
        // Dashboard routes
        this.add('/dashboard', () => Pages.renderDashboard());
        this.add('/dashboard/pages', () => Pages.renderUserPages());
        this.add('/dashboard/pages/create', () => PageBuilder.renderCreatePage());
        this.add('/dashboard/pages/edit/:id', (params) => {
            PageBuilder.currentPage = Storage.getPageById(params.id);
            if (PageBuilder.currentPage) {
                existingImages = PageBuilder.currentPage.images || [];
            }
            return PageBuilder.renderEditPage(params.id);
        });
        this.add('/dashboard/orders', () => Pages.renderUserOrders());
        this.add('/dashboard/settings', () => Pages.renderUserSettings());
        
        // Admin routes
        this.add('/admin', () => Admin.renderAdminDashboard());
        this.add('/admin/users', () => Admin.renderUsers());
        this.add('/admin/pages', () => Admin.renderAllPages());
        this.add('/admin/orders', () => Admin.renderAllOrders());
        
        // Public page route
        this.add('/page/:slug', (params) => PageBuilder.renderPublicPage(params.slug));
        
        // Listen to hash change
        window.addEventListener('hashchange', () => {
            this.navigate(window.location.hash);
        });
        
        // Initial navigation
        this.navigate(window.location.hash || '#/');
    }
};

// Export
window.Router = Router;