// ==================== REUSABLE COMPONENTS ====================

const Components = {
    // Navbar component
    navbar(activeLink = '') {
        const currentUser = Auth.getCurrentUser();
        
        if (!currentUser) {
            return `
                <nav class="navbar">
                    <div class="container navbar-content">
                        <a href="#/" class="navbar-brand">
                            <i class="fas fa-layer-group"></i>
                            PageBuilder SaaS
                        </a>
                        <ul class="navbar-menu">
                            <li><a href="#/login" class="navbar-link ${activeLink === 'login' ? 'active' : ''}">تسجيل الدخول</a></li>
                            <li><a href="#/register" class="navbar-link ${activeLink === 'register' ? 'active' : ''}">التسجيل</a></li>
                        </ul>
                    </div>
                </nav>
            `;
        }

        return `
            <nav class="navbar">
                <div class="container navbar-content">
                    <a href="#/" class="navbar-brand">
                        <i class="fas fa-layer-group"></i>
                        PageBuilder SaaS
                    </a>
                    <ul class="navbar-menu">
                        <li><span class="navbar-link">مرحباً، ${currentUser.name}</span></li>
                        <li><a href="#/dashboard" class="navbar-link ${activeLink === 'dashboard' ? 'active' : ''}">لوحة التحكم</a></li>
                        ${currentUser.role === 'admin' ? `<li><a href="#/admin" class="navbar-link ${activeLink === 'admin' ? 'active' : ''}">الإدارة</a></li>` : ''}
                        <li><a href="#" onclick="handleLogout()" class="navbar-link">تسجيل الخروج</a></li>
                    </ul>
                </div>
            </nav>
        `;
    },

    // Sidebar for dashboard
    sidebar(activeItem = 'overview') {
        const currentUser = Auth.getCurrentUser();
        
        const menuItems = [
            { id: 'overview', icon: 'fa-home', label: 'نظرة عامة', hash: '#/dashboard' },
            { id: 'pages', icon: 'fa-file', label: 'صفحاتي', hash: '#/dashboard/pages' },
            { id: 'orders', icon: 'fa-shopping-cart', label: 'الطلبات', hash: '#/dashboard/orders' },
            { id: 'settings', icon: 'fa-cog', label: 'الإعدادات', hash: '#/dashboard/settings' }
        ];

        return `
            <aside class="sidebar">
                <ul class="sidebar-menu">
                    ${menuItems.map(item => `
                        <li class="sidebar-item">
                            <a href="${item.hash}" class="sidebar-link ${activeItem === item.id ? 'active' : ''}">
                                <i class="fas ${item.icon}"></i>
                                ${item.label}
                            </a>
                        </li>
                    `).join('')}
                </ul>
            </aside>
        `;
    },

    // Admin sidebar
    adminSidebar(activeItem = 'overview') {
        const menuItems = [
            { id: 'overview', icon: 'fa-chart-line', label: 'الإحصائيات', hash: '#/admin' },
            { id: 'users', icon: 'fa-users', label: 'المستخدمين', hash: '#/admin/users' },
            { id: 'pages', icon: 'fa-file', label: 'جميع الصفحات', hash: '#/admin/pages' },
            { id: 'orders', icon: 'fa-shopping-cart', label: 'جميع الطلبات', hash: '#/admin/orders' }
        ];

        return `
            <aside class="sidebar">
                <ul class="sidebar-menu">
                    ${menuItems.map(item => `
                        <li class="sidebar-item">
                            <a href="${item.hash}" class="sidebar-link ${activeItem === item.id ? 'active' : ''}">
                                <i class="fas ${item.icon}"></i>
                                ${item.label}
                            </a>
                        </li>
                    `).join('')}
                </ul>
            </aside>
        `;
    },

    // Stats card
    statCard(icon, value, label, colorClass = '') {
        return `
            <div class="stat-card ${colorClass}">
                <div class="stat-icon">
                    <i class="fas ${icon}"></i>
                </div>
                <div class="stat-value">${value}</div>
                <div class="stat-label">${label}</div>
            </div>
        `;
    },

    // Page card
    pageCard(page) {
        const statusBadge = page.status === 'active' 
            ? '<span class="badge badge-success">نشط</span>' 
            : '<span class="badge badge-warning">متوقف</span>';

        const conversionRate = page.visits > 0 
            ? ((page.orders / page.visits) * 100).toFixed(1) 
            : 0;

        return `
            <div class="card">
                <div class="card-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h3 style="margin-bottom: 0.25rem;">${page.title}</h3>
                            <small style="color: var(--text-secondary);">/${page.slug}</small>
                        </div>
                        ${statusBadge}
                    </div>
                </div>
                <div class="card-body">
                    <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 1rem; margin-bottom: 1rem;">
                        <div style="text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--primary);">${Utils.formatNumber(page.visits)}</div>
                            <div style="font-size: 0.85rem; color: var(--text-secondary);">زيارة</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--success);">${Utils.formatNumber(page.orders)}</div>
                            <div style="font-size: 0.85rem; color: var(--text-secondary);">طلب</div>
                        </div>
                        <div style="text-align: center;">
                            <div style="font-size: 1.5rem; font-weight: 700; color: var(--warning);">${conversionRate}%</div>
                            <div style="font-size: 0.85rem; color: var(--text-secondary);">تحويل</div>
                        </div>
                    </div>
                    <div style="font-size: 1.25rem; font-weight: 700; color: var(--primary); margin-bottom: 0.5rem;">
                        ${Utils.formatCurrency(page.price)}
                    </div>
                </div>
                <div class="card-footer">
                    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                        <a href="#/page/${page.slug}" class="btn btn-primary" target="_blank">
                            <i class="fas fa-eye"></i> عرض
                        </a>
                        <a href="#/dashboard/pages/edit/${page.id}" class="btn btn-secondary">
                            <i class="fas fa-edit"></i> تعديل
                        </a>
                        <button class="btn btn-secondary" onclick="copyPageLink('${page.slug}')">
                            <i class="fas fa-copy"></i> نسخ الرابط
                        </button>
                        <button class="btn btn-danger" onclick="deletePage('${page.id}')">
                            <i class="fas fa-trash"></i> حذف
                        </button>
                    </div>
                </div>
            </div>
        `;
    },

    // Order card
    orderCard(order) {
        const page = Storage.getPageById(order.pageId);
        const pageName = page ? page.title : 'صفحة محذوفة';
        
        const statusMap = {
            pending: { label: 'قيد الانتظار', class: 'warning' },
            confirmed: { label: 'مؤكد', class: 'info' },
            completed: { label: 'مكتمل', class: 'success' },
            cancelled: { label: 'ملغي', class: 'error' }
        };
        
        const status = statusMap[order.status] || statusMap.pending;
        const whatsappUrl = `https://wa.me/${Utils.formatPhoneForWhatsApp(order.customerPhone)}`;

        return `
            <div class="card">
                <div class="card-header">
                    <div style="display: flex; justify-content: space-between; align-items: center;">
                        <div>
                            <h4 style="margin-bottom: 0.25rem;">${order.customerName}</h4>
                            <small style="color: var(--text-secondary);">${pageName}</small>
                        </div>
                        <span class="badge badge-${status.class}">${status.label}</span>
                    </div>
                </div>
                <div class="card-body">
                    <div style="margin-bottom: 1rem;">
                        <div style="margin-bottom: 0.5rem;">
                            <strong>الهاتف:</strong> 
                            <a href="${whatsappUrl}" target="_blank" style="color: var(--success); text-decoration: none;">
                                <i class="fab fa-whatsapp"></i> ${order.customerPhone}
                            </a>
                        </div>
                        <div style="margin-bottom: 0.5rem;">
                            <strong>العنوان:</strong> ${order.customerAddress}
                        </div>
                        <div style="margin-bottom: 0.5rem;">
                            <strong>الكمية:</strong> ${order.quantity}
                        </div>
                        <div style="margin-bottom: 0.5rem;">
                            <strong>المبلغ:</strong> ${Utils.formatCurrency(order.totalPrice)}
                        </div>
                        ${order.notes ? `
                            <div style="margin-bottom: 0.5rem;">
                                <strong>ملاحظات:</strong> ${order.notes}
                            </div>
                        ` : ''}
                        <div style="color: var(--text-secondary); font-size: 0.85rem;">
                            ${Utils.formatDate(order.createdAt)}
                        </div>
                    </div>
                </div>
                <div class="card-footer">
                    <div style="display: flex; gap: 0.5rem; flex-wrap: wrap;">
                        <a href="${whatsappUrl}" target="_blank" class="btn btn-success">
                            <i class="fab fa-whatsapp"></i> واتساب
                        </a>
                        <button class="btn btn-secondary" onclick="updateOrderStatus('${order.id}', 'confirmed')">
                            <i class="fas fa-check"></i> تأكيد
                        </button>
                        <button class="btn btn-primary" onclick="updateOrderStatus('${order.id}', 'completed')">
                            <i class="fas fa-check-double"></i> مكتمل
                        </button>
                        <button class="btn btn-danger" onclick="updateOrderStatus('${order.id}', 'cancelled')">
                            <i class="fas fa-times"></i> إلغاء
                        </button>
                    </div>
                </div>
            </div>
        `;
    },

    // Empty state
    emptyState(icon, title, description, actionText = '', actionCallback = '') {
        return `
            <div style="text-align: center; padding: 3rem 1rem;">
                <div style="font-size: 4rem; color: var(--text-tertiary); margin-bottom: 1rem;">
                    <i class="fas ${icon}"></i>
                </div>
                <h3 style="font-size: 1.5rem; margin-bottom: 0.5rem;">${title}</h3>
                <p style="color: var(--text-secondary); margin-bottom: 1.5rem;">${description}</p>
                ${actionText ? `
                    <button class="btn btn-primary" onclick="${actionCallback}">
                        ${actionText}
                    </button>
                ` : ''}
            </div>
        `;
    },

    // Loading state
    loading() {
        return `
            <div style="text-align: center; padding: 3rem;">
                <div class="spinner" style="margin: 0 auto;"></div>
                <p style="margin-top: 1rem; color: var(--text-secondary);">جاري التحميل...</p>
            </div>
        `;
    },

    // Modal
    modal(id, title, body, footer = '', size = '') {
        return `
            <div id="${id}" class="modal-overlay" style="display: none;">
                <div class="modal ${size}">
                    <div class="modal-header">
                        <h3 class="modal-title">${title}</h3>
                        <button class="modal-close" onclick="closeModal('${id}')">&times;</button>
                    </div>
                    <div class="modal-body">
                        ${body}
                    </div>
                    ${footer ? `
                        <div class="modal-footer">
                            ${footer}
                        </div>
                    ` : ''}
                </div>
            </div>
        `;
    }
};

// Global helper functions
window.copyPageLink = function(slug) {
    const url = `${window.location.origin}${window.location.pathname}#/page/${slug}`;
    Utils.copyToClipboard(url);
};

window.deletePage = function(pageId) {
    if (Utils.confirm('هل أنت متأكد من حذف هذه الصفحة؟')) {
        Storage.deletePage(pageId);
        Utils.showToast('تم حذف الصفحة بنجاح', 'success');
        window.location.reload();
    }
};

window.updateOrderStatus = function(orderId, status) {
    Storage.updateOrder(orderId, { status });
    Utils.showToast('تم تحديث حالة الطلب', 'success');
    window.location.reload();
};

window.closeModal = function(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.style.display = 'none';
    }
};

window.openModal = function(id) {
    const modal = document.getElementById(id);
    if (modal) {
        modal.style.display = 'flex';
    }
};

window.handleLogout = function() {
    Auth.logout();
    Utils.showToast('تم تسجيل الخروج بنجاح', 'success');
    window.location.hash = '#/';
};

// Export
window.Components = Components;