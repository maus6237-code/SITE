// ==================== ADMIN MANAGER ====================

const Admin = {
    // Render admin dashboard
    renderAdminDashboard() {
        if (!Auth.requireAdmin()) return;
        
        const stats = Analytics.getAdminStats();
        const topPages = Analytics.getTopPages(null, 5);
        const recentOrders = Analytics.getRecentOrders(null, 10);
        const revenueData = Analytics.getRevenueByPeriod(null, 7);

        return `
            ${Components.navbar('admin')}
            <div class="dashboard-layout">
                ${Components.adminSidebar('overview')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">
                        <i class="fas fa-chart-line"></i> لوحة الإدارة
                    </h1>
                    
                    <div class="stats-grid">
                        ${Components.statCard('fa-users', Utils.formatNumber(stats.totalUsers), 'إجمالي المستخدمين', 'info')}
                        ${Components.statCard('fa-file', Utils.formatNumber(stats.totalPages), 'إجمالي الصفحات', 'success')}
                        ${Components.statCard('fa-eye', Utils.formatNumber(stats.totalVisits), 'إجمالي الزيارات', '')}
                        ${Components.statCard('fa-shopping-cart', Utils.formatNumber(stats.totalOrders), 'إجمالي الطلبات', 'warning')}
                    </div>

                    <div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: var(--shadow-md); margin-bottom: 2rem;">
                        <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 1rem;">
                            <i class="fas fa-coins"></i> إجمالي الإيرادات
                        </h2>
                        <div style="font-size: 3rem; font-weight: 800; color: var(--success);">
                            ${Utils.formatCurrency(stats.totalRevenue)}
                        </div>
                        <div style="display: flex; gap: 2rem; margin-top: 1rem;">
                            <div>
                                <div style="color: var(--text-secondary);">الطلبات المكتملة</div>
                                <div style="font-size: 1.5rem; font-weight: 700;">${Utils.formatNumber(stats.completedOrders)}</div>
                            </div>
                            <div>
                                <div style="color: var(--text-secondary);">معدل التحويل</div>
                                <div style="font-size: 1.5rem; font-weight: 700; color: var(--primary);">${stats.conversionRate}%</div>
                            </div>
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(400px, 1fr)); gap: 1.5rem; margin-bottom: 2rem;">
                        ${Analytics.renderSimpleChart(revenueData, 'date', 'revenue', '<i class="fas fa-chart-area"></i> الإيرادات اليومية')}
                        ${Analytics.renderSimpleChart(revenueData, 'date', 'orders', '<i class="fas fa-chart-bar"></i> الطلبات اليومية')}
                    </div>

                    <div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: var(--shadow-md); margin-bottom: 2rem;">
                        <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 1.5rem;">
                            <i class="fas fa-trophy"></i> أفضل الصفحات أداءً
                        </h2>
                        ${topPages.length > 0 ? `
                            <div class="table-container">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>الصفحة</th>
                                            <th>الزيارات</th>
                                            <th>الطلبات</th>
                                            <th>معدل التحويل</th>
                                            <th>الإيرادات</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        ${topPages.map(page => `
                                            <tr>
                                                <td>
                                                    <div style="font-weight: 600;">${page.title}</div>
                                                    <small style="color: var(--text-secondary);">/${page.slug}</small>
                                                </td>
                                                <td>${Utils.formatNumber(page.visits)}</td>
                                                <td>${Utils.formatNumber(page.totalOrders)}</td>
                                                <td>${page.conversionRate}%</td>
                                                <td style="font-weight: 700; color: var(--success);">
                                                    ${Utils.formatCurrency(page.revenue)}
                                                </td>
                                            </tr>
                                        `).join('')}
                                    </tbody>
                                </table>
                            </div>
                        ` : '<p style="text-align: center; color: var(--text-secondary);">لا توجد بيانات</p>'}
                    </div>

                    <div style="background: white; padding: 2rem; border-radius: 12px; box-shadow: var(--shadow-md);">
                        <h2 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 1.5rem;">
                            <i class="fas fa-clock"></i> آخر الطلبات
                        </h2>
                        ${recentOrders.length > 0 ? `
                            <div style="display: grid; gap: 1rem;">
                                ${recentOrders.slice(0, 5).map(order => {
                                    const statusMap = {
                                        pending: { label: 'قيد الانتظار', class: 'warning' },
                                        confirmed: { label: 'مؤكد', class: 'info' },
                                        completed: { label: 'مكتمل', class: 'success' },
                                        cancelled: { label: 'ملغي', class: 'error' }
                                    };
                                    const status = statusMap[order.status] || statusMap.pending;
                                    
                                    return `
                                        <div style="padding: 1rem; background: var(--bg-secondary); border-radius: 8px;">
                                            <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 0.5rem;">
                                                <div>
                                                    <div style="font-weight: 600;">${order.customerName}</div>
                                                    <div style="font-size: 0.9rem; color: var(--text-secondary);">${order.pageName}</div>
                                                </div>
                                                <span class="badge badge-${status.class}">${status.label}</span>
                                            </div>
                                            <div style="display: flex; justify-content: space-between; font-size: 0.9rem;">
                                                <span>${Utils.formatDate(order.createdAt)}</span>
                                                <span style="font-weight: 700; color: var(--primary);">
                                                    ${Utils.formatCurrency(order.totalPrice)}
                                                </span>
                                            </div>
                                        </div>
                                    `;
                                }).join('')}
                            </div>
                        ` : '<p style="text-align: center; color: var(--text-secondary);">لا توجد طلبات</p>'}
                    </div>
                </main>
            </div>
        `;
    },

    // Render users management
    renderUsers() {
        if (!Auth.requireAdmin()) return;
        
        const users = Storage.getAllUsers();
        const currentUser = Auth.getCurrentUser();

        return `
            ${Components.navbar('admin')}
            <div class="dashboard-layout">
                ${Components.adminSidebar('users')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">
                        <i class="fas fa-users"></i> إدارة المستخدمين
                    </h1>
                    
                    <div class="table-container">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>الاسم</th>
                                    <th>البريد الإلكتروني</th>
                                    <th>الدور</th>
                                    <th>تاريخ التسجيل</th>
                                    <th>الصفحات</th>
                                    <th>الطلبات</th>
                                    <th>الإجراءات</th>
                                </tr>
                            </thead>
                            <tbody>
                                ${users.map(user => {
                                    const userPages = Storage.getPagesByUser(user.id);
                                    const userOrders = Storage.getOrdersByUser(user.id);
                                    const isCurrentUser = user.id === currentUser.id;
                                    
                                    return `
                                        <tr>
                                            <td style="font-weight: 600;">
                                                ${user.name}
                                                ${isCurrentUser ? '<span class="badge badge-info" style="margin-right: 0.5rem;">أنت</span>' : ''}
                                            </td>
                                            <td>${user.email}</td>
                                            <td>
                                                ${user.role === 'admin' 
                                                    ? '<span class="badge badge-error">مدير</span>' 
                                                    : '<span class="badge badge-success">عميل</span>'}
                                            </td>
                                            <td>${Utils.formatDate(user.createdAt)}</td>
                                            <td>${userPages.length}</td>
                                            <td>${userOrders.length}</td>
                                            <td>
                                                ${!isCurrentUser ? `
                                                    <button class="btn btn-danger" style="padding: 0.5rem 1rem;" 
                                                        onclick="deleteUser('${user.id}')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                ` : '<span style="color: var(--text-tertiary);">-</span>'}
                                            </td>
                                        </tr>
                                    `;
                                }).join('')}
                            </tbody>
                        </table>
                    </div>
                </main>
            </div>
        `;
    },

    // Render all pages
    renderAllPages() {
        if (!Auth.requireAdmin()) return;
        
        const pages = Storage.getAllPages();

        return `
            ${Components.navbar('admin')}
            <div class="dashboard-layout">
                ${Components.adminSidebar('pages')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">
                        <i class="fas fa-file"></i> جميع الصفحات
                    </h1>
                    
                    ${pages.length > 0 ? `
                        <div style="display: grid; gap: 1.5rem;">
                            ${pages.map(page => {
                                const user = Storage.getUserById(page.userId);
                                const userName = user ? user.name : 'مستخدم محذوف';
                                return Components.pageCard(page).replace(
                                    '<h3 style="margin-bottom: 0.25rem;">',
                                    `<small style="color: var(--text-secondary); display: block; margin-bottom: 0.5rem;">
                                        <i class="fas fa-user"></i> ${userName}
                                    </small>
                                    <h3 style="margin-bottom: 0.25rem;">`
                                );
                            }).join('')}
                        </div>
                    ` : Components.emptyState('fa-file', 'لا توجد صفحات', 'لم يتم إنشاء أي صفحات بعد')}
                </main>
            </div>
        `;
    },

    // Render all orders
    renderAllOrders() {
        if (!Auth.requireAdmin()) return;
        
        const orders = Storage.getAllOrders().sort((a, b) => b.createdAt - a.createdAt);

        return `
            ${Components.navbar('admin')}
            <div class="dashboard-layout">
                ${Components.adminSidebar('orders')}
                <main class="main-content">
                    <h1 style="font-size: 2rem; font-weight: 800; margin-bottom: 2rem;">
                        <i class="fas fa-shopping-cart"></i> جميع الطلبات
                    </h1>
                    
                    ${orders.length > 0 ? `
                        <div style="display: grid; gap: 1.5rem;">
                            ${orders.map(order => {
                                const user = Storage.getUserById(order.userId);
                                const userName = user ? user.name : 'مستخدم محذوف';
                                return Components.orderCard(order).replace(
                                    '<small style="color: var(--text-secondary);">',
                                    `<small style="color: var(--text-secondary); display: block;">
                                        <i class="fas fa-user"></i> ${userName}<br>`
                                );
                            }).join('')}
                        </div>
                    ` : Components.emptyState('fa-shopping-cart', 'لا توجد طلبات', 'لم يتم استلام أي طلبات بعد')}
                </main>
            </div>
        `;
    }
};

// Global handlers
window.deleteUser = function(userId) {
    if (Utils.confirm('هل أنت متأكد من حذف هذا المستخدم؟')) {
        Storage.deleteUser(userId);
        Utils.showToast('تم حذف المستخدم بنجاح', 'success');
        window.location.reload();
    }
};

// Export
window.Admin = Admin;