// ==================== ORDERS MANAGER ====================

const Orders = {
    // Create order form
    renderOrderForm(page) {
        return `
            <form id="orderForm" onsubmit="handleSubmitOrder(event, '${page.id}', ${page.price})" class="order-form">
                <h3 style="font-size: 1.5rem; font-weight: 700; margin-bottom: 1.5rem;">
                    <i class="fas fa-shopping-cart"></i> معلومات الطلب
                </h3>
                
                <div class="form-group">
                    <label class="form-label">الاسم الكامل *</label>
                    <input type="text" class="form-control" id="customerName" required>
                </div>
                
                <div class="form-group">
                    <label class="form-label">رقم الهاتف (واتساب) *</label>
                    <input type="tel" class="form-control" id="customerPhone" placeholder="+212612345678" required>
                    <small style="color: var(--text-secondary);">مثال: 0612345678 أو +212612345678</small>
                </div>
                
                <div class="form-group">
                    <label class="form-label">العنوان *</label>
                    <textarea class="form-control" id="customerAddress" rows="3" required></textarea>
                </div>
                
                <div class="form-group">
                    <label class="form-label">الكمية</label>
                    <input type="number" class="form-control" id="quantity" value="1" min="1" required onchange="updateTotalPrice(${page.price})">
                </div>
                
                <div class="form-group">
                    <label class="form-label">ملاحظات إضافية</label>
                    <textarea class="form-control" id="notes" rows="3" placeholder="أي ملاحظات إضافية..."></textarea>
                </div>
                
                <div style="background: var(--bg-tertiary); padding: 1.5rem; border-radius: 8px; margin-bottom: 1.5rem;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <span style="font-weight: 600;">السعر:</span>
                        <span style="font-size: 1.25rem; color: var(--primary);">${Utils.formatCurrency(page.price)}</span>
                    </div>
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem;">
                        <span style="font-weight: 600;">الكمية:</span>
                        <span id="displayQuantity">1</span>
                    </div>
                    <div style="border-top: 2px solid var(--border-color); margin: 0.5rem 0; padding-top: 0.5rem;">
                        <div style="display: flex; justify-content: space-between; align-items: center;">
                            <span style="font-weight: 700; font-size: 1.125rem;">المجموع:</span>
                            <span id="totalPrice" style="font-size: 1.5rem; font-weight: 800; color: var(--success);">
                                ${Utils.formatCurrency(page.price)}
                            </span>
                        </div>
                    </div>
                </div>
                
                <button type="submit" class="btn btn-primary" style="width: 100%; padding: 1rem; font-size: 1.125rem;">
                    <i class="fas fa-check"></i> تأكيد الطلب
                </button>
            </form>
        `;
    },

    // Success message
    renderOrderSuccess() {
        return `
            <div style="text-align: center; padding: 3rem 1rem;">
                <div style="font-size: 5rem; color: var(--success); margin-bottom: 1.5rem;">
                    <i class="fas fa-check-circle"></i>
                </div>
                <h2 style="font-size: 2rem; font-weight: 800; margin-bottom: 1rem; color: var(--success);">
                    تم استلام طلبك بنجاح!
                </h2>
                <p style="font-size: 1.125rem; color: var(--text-secondary); margin-bottom: 2rem;">
                    سيتم التواصل معك قريباً عبر واتساب لتأكيد الطلب
                </p>
                <div style="background: var(--bg-secondary); padding: 1.5rem; border-radius: 12px; margin-bottom: 2rem;">
                    <p style="margin-bottom: 1rem;">
                        <i class="fas fa-info-circle"></i>
                        يرجى التأكد من أن هاتفك متاح لاستقبال المكالمات
                    </p>
                </div>
            </div>
        `;
    }
};

// Global handler for order submission
window.handleSubmitOrder = function(event, pageId, pricePerUnit) {
    event.preventDefault();
    
    const customerName = document.getElementById('customerName').value;
    const customerPhone = document.getElementById('customerPhone').value;
    const customerAddress = document.getElementById('customerAddress').value;
    const notes = document.getElementById('notes').value;
    const quantity = parseInt(document.getElementById('quantity').value) || 1;
    
    // Validate phone
    if (!Utils.validateMoroccanPhone(customerPhone)) {
        Utils.showToast('رقم الهاتف غير صالح. يرجى إدخال رقم مغربي صحيح', 'error');
        return;
    }
    
    // Get page details
    const page = Storage.getPageById(pageId);
    if (!page) {
        Utils.showToast('الصفحة غير موجودة', 'error');
        return;
    }
    
    // Calculate total
    const totalPrice = pricePerUnit * quantity;
    
    // Create order
    const result = Storage.createOrder({
        pageId: pageId,
        userId: page.userId,
        customerName,
        customerPhone,
        customerAddress,
        notes,
        quantity,
        totalPrice
    });
    
    if (result.success) {
        // Show success message
        const productPage = document.getElementById('app');
        productPage.innerHTML = `
            ${Components.navbar()}
            <div class="product-page">
                ${Orders.renderOrderSuccess()}
            </div>
        `;
        
        // Scroll to top
        window.scrollTo(0, 0);
        
        // Open WhatsApp after 2 seconds
        setTimeout(() => {
            const whatsappPhone = Utils.formatPhoneForWhatsApp(customerPhone);
            const message = `مرحباً، لقد قمت بطلب ${page.title} من موقعكم`;
            window.open(`https://wa.me/${whatsappPhone}?text=${encodeURIComponent(message)}`, '_blank');
        }, 2000);
    } else {
        Utils.showToast(result.message, 'error');
    }
};

window.updateTotalPrice = function(pricePerUnit) {
    const quantity = parseInt(document.getElementById('quantity').value) || 1;
    const totalPrice = pricePerUnit * quantity;
    
    document.getElementById('displayQuantity').textContent = quantity;
    document.getElementById('totalPrice').textContent = Utils.formatCurrency(totalPrice);
};

// Export
window.Orders = Orders;