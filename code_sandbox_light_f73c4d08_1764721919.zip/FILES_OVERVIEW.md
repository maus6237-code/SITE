# 📁 نظرة عامة على ملفات المشروع - PageBuilder SaaS

دليل شامل لجميع ملفات المشروع ووظيفة كل منها.

---

## 📂 هيكل المشروع الكامل

```
PageBuilderSaaS/
│
├── 📄 index.html                 (1.3 KB)  - الصفحة الرئيسية
│
├── 📁 css/
│   └── 📄 style.css             (15.6 KB) - جميع الأنماط والتصاميم
│
├── 📁 js/
│   ├── 📄 app.js                (2.3 KB)  - نقطة البداية الرئيسية
│   ├── 📄 router.js             (4.1 KB)  - نظام التوجيه (Routing)
│   ├── 📄 utils.js              (7.5 KB)  - وظائف مساعدة عامة
│   ├── 📄 storage.js            (10.5 KB) - إدارة localStorage
│   ├── 📄 auth.js               (4.7 KB)  - نظام المصادقة
│   ├── 📄 components.js         (14.4 KB) - مكونات قابلة لإعادة الاستخدام
│   ├── 📄 pages.js              (20.4 KB) - صفحات التطبيق الرئيسية
│   ├── 📄 orders.js             (6.9 KB)  - إدارة الطلبات
│   ├── 📄 analytics.js          (7.6 KB)  - الإحصائيات والتحليلات
│   ├── 📄 admin.js              (15.4 KB) - لوحة الإدارة
│   └── 📄 pagebuilder.js        (17.2 KB) - محرر الصفحات
│
└── 📚 Documentation/
    ├── 📄 README.md             (10.6 KB) - الدليل الرئيسي
    ├── 📄 QUICK_START.md        (8.6 KB)  - دليل البدء السريع
    ├── 📄 FEATURES.md           (15.9 KB) - قائمة المميزات الكاملة
    ├── 📄 CHANGELOG.md          (6.7 KB)  - سجل التغييرات
    ├── 📄 TROUBLESHOOTING.md    (15.0 KB) - دليل حل المشاكل
    ├── 📄 PROJECT_SUMMARY.md    (11.3 KB) - ملخص المشروع
    ├── 📄 DEPLOYMENT.md         (10.9 KB) - دليل النشر
    └── 📄 FILES_OVERVIEW.md     (هذا الملف) - نظرة عامة على الملفات

📊 الإحصائيات:
├── إجمالي الملفات: 20 ملف
├── ملفات الكود: 12 ملف
├── ملفات التوثيق: 8 ملفات
└── الحجم الإجمالي: ~160 KB
```

---

## 📄 الملفات الرئيسية

### 1. index.html
**الحجم:** 1.3 KB  
**الغرض:** الصفحة الرئيسية والوحيدة (SPA)

**المحتوى:**
- هيكل HTML5 الأساسي
- روابط CSS (style.css, Font Awesome, Google Fonts)
- حاوية التطبيق (`<div id="app">`)
- شاشة تحميل
- حاوية الإشعارات (Toast)
- روابط جميع ملفات JavaScript بالترتيب الصحيح

**المكتبات المحملة:**
- Font Awesome 6.4.0 (CDN)
- Google Fonts - Cairo (CDN)

---

## 🎨 ملفات CSS

### 1. css/style.css
**الحجم:** 15.6 KB  
**الأسطر:** ~633 سطر

**الأقسام:**

1. **RESET & BASE** - إعادة تعيين الأنماط الافتراضية
   - Reset جميع العناصر
   - CSS Variables للألوان
   - الخطوط الأساسية

2. **UTILITY CLASSES** - فئات مساعدة
   - Container
   - Hidden
   - Text alignment
   - Margins

3. **LOADING SPINNER** - شاشة التحميل
   - تراكب شفاف
   - Spinner دوار
   - رسوم متحركة

4. **TOAST NOTIFICATIONS** - الإشعارات
   - 4 أنواع (Success, Error, Warning, Info)
   - رسوم متحركة
   - تموضع ذكي

5. **BUTTONS** - الأزرار
   - Primary, Secondary, Success, Danger
   - Outline style
   - حالات Hover & Disabled

6. **FORMS** - النماذج
   - Form groups
   - Labels & Inputs
   - Textareas
   - رسائل الخطأ
   - Focus effects

7. **CARDS** - البطاقات
   - Header, Body, Footer
   - Hover effects
   - Shadows

8. **NAVIGATION** - القوائم
   - Navbar
   - Sidebar
   - روابط نشطة

9. **TABLES** - الجداول
   - تصميم نظيف
   - Hover على الصفوف
   - متجاوب

10. **BADGES** - الشارات
    - 4 ألوان
    - مدورة

11. **STATS CARDS** - بطاقات الإحصائيات
    - تدرجات لونية
    - أيقونات كبيرة
    - أرقام بارزة

12. **MODAL** - النوافذ المنبثقة
    - تراكب
    - رسوم متحركة
    - Header, Body, Footer

13. **AUTH PAGES** - صفحات المصادقة
    - تصميم مركزي
    - خلفية متدرجة
    - بطاقة أنيقة

14. **PAGE BUILDER** - محرر الصفحات
    - Grid layout
    - Canvas
    - Sidebar
    - Preview

15. **PRODUCT PAGE** - صفحة المنتج
    - رأس بصورة
    - معرض صور
    - نموذج طلب

16. **RESPONSIVE** - التجاوب
    - Mobile (< 768px)
    - Tablet (768px - 1024px)
    - Desktop (> 1024px)

17. **ANIMATIONS** - الرسوم المتحركة
    - Pulse
    - Slide
    - Fade

18. **SCROLLBAR** - شريط التمرير
    - تصميم مخصص
    - ألوان متناسقة

---

## 💻 ملفات JavaScript

### 1. js/app.js (2.3 KB)
**الغرض:** نقطة البداية - تهيئة التطبيق

**الوظائف:**
- تهيئة Storage
- تهيئة Router
- معالجة الأخطاء
- Service Worker (اختياري)
- عرض معلومات التطبيق

**Events:**
- `DOMContentLoaded` - بداية التطبيق
- `error` - معالجة الأخطاء العامة
- `unhandledrejection` - معالجة Promise errors

---

### 2. js/router.js (4.1 KB)
**الغرض:** نظام التوجيه (SPA Router)

**الوظائف الرئيسية:**
- `add(path, handler)` - إضافة مسار
- `navigate(hash)` - التنقل لمسار
- `createPattern(route)` - إنشاء Regex pattern
- `extractParams(route, path)` - استخراج المعاملات
- `notFound()` - صفحة 404
- `init()` - تهيئة Router

**المسارات المعرّفة:** 20+ مسار

**الميزات:**
- دعم المعاملات الديناميكية (`:id`, `:slug`)
- Hash-based routing (`#/path`)
- 404 تلقائي
- History integration

---

### 3. js/utils.js (7.5 KB)
**الغرض:** وظائف مساعدة عامة

**الوظائف الرئيسية:**
- `generateId()` - توليد ID فريد
- `generateSlug(text)` - توليد Slug
- `formatDate(timestamp)` - تنسيق التاريخ
- `formatNumber(num)` - تنسيق الأرقام
- `formatCurrency(amount)` - تنسيق العملة
- `validateMoroccanPhone(phone)` - التحقق من الهاتف
- `formatPhoneForWhatsApp(phone)` - تنسيق للواتساب
- `validateEmail(email)` - التحقق من البريد
- `showToast(message, type)` - عرض إشعار
- `showLoading()` / `hideLoading()` - شاشة تحميل
- `copyToClipboard(text)` - نسخ للحافظة
- `imageToBase64(file)` - تحويل صورة لـ Base64
- `compressImage(file)` - ضغط صورة

**المجموع:** 20+ وظيفة

---

### 4. js/storage.js (10.5 KB)
**الغرض:** إدارة localStorage

**المفاتيح:**
- `pagebuilder_users` - المستخدمين
- `pagebuilder_pages` - الصفحات
- `pagebuilder_orders` - الطلبات
- `pagebuilder_current_user` - المستخدم الحالي
- `pagebuilder_visits` - الزيارات

**الوظائف الأساسية:**
- `get(key)` / `set(key, value)` / `remove(key)`
- `init()` - تهيئة مع بيانات افتراضية

**عمليات المستخدمين:**
- `createUser()` / `getUserById()` / `getUserByEmail()`
- `getAllUsers()` / `updateUser()` / `deleteUser()`
- `setCurrentUser()` / `getCurrentUser()` / `clearCurrentUser()`

**عمليات الصفحات:**
- `createPage()` / `getPageById()` / `getPageBySlug()`
- `getPagesByUser()` / `getAllPages()`
- `updatePage()` / `deletePage()`
- `incrementPageVisits()` / `incrementPageOrders()`

**عمليات الطلبات:**
- `createOrder()` / `getOrderById()`
- `getOrdersByUser()` / `getOrdersByPage()`
- `getAllOrders()` / `updateOrder()` / `deleteOrder()`

**تتبع الزيارات:**
- `trackVisit(pageId)` - تسجيل زيارة
- `getVisitsByPage(pageId, days)` - جلب زيارات

**المجموع:** 30+ وظيفة

---

### 5. js/auth.js (4.7 KB)
**الغرض:** نظام المصادقة والتحقق

**الوظائف الرئيسية:**
- `login(email, password)` - تسجيل دخول
- `register(name, email, password, confirmPassword)` - تسجيل
- `logout()` - تسجيل خروج
- `getCurrentUser()` - جلب المستخدم الحالي
- `isLoggedIn()` - التحقق من تسجيل الدخول
- `isAdmin()` - التحقق من الدور
- `requireAuth()` - طلب تسجيل دخول
- `requireAdmin()` - طلب صلاحيات مدير
- `updateProfile(updates)` - تحديث الملف الشخصي
- `changePassword()` - تغيير كلمة المرور

**الميزات:**
- تشفير كلمات المرور
- التحقق من البريد الإلكتروني
- التحقق من قوة كلمة المرور
- حماية المسارات

---

### 6. js/components.js (14.4 KB)
**الغرض:** مكونات واجهة قابلة لإعادة الاستخدام

**المكونات:**
- `navbar(activeLink)` - شريط التنقل العلوي
- `sidebar(activeItem)` - القائمة الجانبية للمستخدم
- `adminSidebar(activeItem)` - القائمة الجانبية للمدير
- `statCard(icon, value, label, colorClass)` - بطاقة إحصائية
- `pageCard(page)` - بطاقة صفحة
- `orderCard(order)` - بطاقة طلب
- `emptyState(icon, title, description, action)` - حالة فارغة
- `loading()` - حالة تحميل
- `modal(id, title, body, footer)` - نافذة منبثقة

**وظائف مساعدة عالمية:**
- `copyPageLink(slug)` - نسخ رابط الصفحة
- `deletePage(pageId)` - حذف صفحة
- `updateOrderStatus(orderId, status)` - تحديث حالة طلب
- `openModal(id)` / `closeModal(id)` - إدارة المودال
- `handleLogout()` - تسجيل خروج

---

### 7. js/pages.js (20.4 KB)
**الغرض:** صفحات التطبيق الرئيسية

**الصفحات:**
- `renderHome()` - الصفحة الرئيسية
- `renderLogin()` - صفحة تسجيل الدخول
- `renderRegister()` - صفحة التسجيل
- `renderDashboard()` - لوحة التحكم
- `renderUserPages()` - صفحات المستخدم
- `renderUserOrders()` - طلبات المستخدم
- `renderUserSettings()` - إعدادات المستخدم

**معالجات النماذج:**
- `handleLogin(event)` - معالج تسجيل الدخول
- `handleRegister(event)` - معالج التسجيل
- `handleUpdateProfile(event)` - معالج تحديث الملف
- `handleChangePassword(event)` - معالج تغيير كلمة المرور

---

### 8. js/orders.js (6.9 KB)
**الغرض:** إدارة الطلبات

**الوظائف:**
- `renderOrderForm(page)` - نموذج طلب
- `renderOrderSuccess()` - رسالة نجاح

**معالجات:**
- `handleSubmitOrder(event, pageId, price)` - إرسال طلب
- `updateTotalPrice(pricePerUnit)` - تحديث المجموع

**الميزات:**
- حساب تلقائي للمجموع
- التحقق من رقم الهاتف
- تكامل WhatsApp تلقائي
- صفحة تأكيد جميلة

---

### 9. js/analytics.js (7.6 KB)
**الغرض:** الإحصائيات والتحليلات

**الوظائف:**
- `getUserStats(userId)` - إحصائيات مستخدم
- `getAdminStats()` - إحصائيات عامة
- `getPagePerformance(pageId)` - أداء صفحة
- `getTopPages(userId, limit)` - أفضل الصفحات
- `getRecentOrders(userId, limit)` - آخر الطلبات
- `getOrdersByStatus(status, userId)` - طلبات حسب الحالة
- `getRevenueByPeriod(userId, days)` - إيرادات حسب الفترة
- `getVisitsByPeriod(pageId, days)` - زيارات حسب الفترة
- `renderSimpleChart(data, labelKey, valueKey, title)` - رسم مخطط

**المقاييس:**
- الزيارات
- الطلبات
- معدل التحويل
- معدل الإكمال
- الإيرادات

---

### 10. js/admin.js (15.4 KB)
**الغرض:** لوحة الإدارة

**الصفحات:**
- `renderAdminDashboard()` - لوحة الإدارة الرئيسية
- `renderUsers()` - إدارة المستخدمين
- `renderAllPages()` - إدارة جميع الصفحات
- `renderAllOrders()` - إدارة جميع الطلبات

**معالجات:**
- `deleteUser(userId)` - حذف مستخدم

**الميزات:**
- عرض إحصائيات شاملة
- إدارة كاملة للمستخدمين
- مراقبة جميع الصفحات
- تتبع جميع الطلبات

---

### 11. js/pagebuilder.js (17.2 KB)
**الغرض:** محرر إنشاء وتعديل الصفحات

**الصفحات:**
- `renderCreatePage()` - نموذج إنشاء صفحة
- `renderEditPage(pageId)` - نموذج تعديل صفحة
- `renderPublicPage(slug)` - الصفحة العامة

**معالجات:**
- `handleImageUpload(event)` - رفع صور
- `removeUploadedImage(index)` - حذف صورة جديدة
- `removeExistingImage(index)` - حذف صورة موجودة
- `handleCreatePage(event)` - إنشاء صفحة
- `handleEditPage(event, pageId)` - تعديل صفحة
- `changeMainImage(src, event)` - تبديل الصورة الرئيسية

**الميزات:**
- رفع صور متعددة
- ضغط الصور تلقائياً
- معاينة فورية
- تخصيص الألوان
- Slug تلقائي
- معرض صور تفاعلي

---

## 📚 ملفات التوثيق

### 1. README.md (10.6 KB)
**الغرض:** الدليل الرئيسي الشامل

**الأقسام:**
- نظرة عامة
- المميزات الرئيسية
- التقنيات المستخدمة
- هيكل المشروع
- البدء السريع
- المسارات الرئيسية
- التخزين المحلي
- الأمان
- الميزات المكتملة
- الميزات المستقبلية
- حل المشاكل
- المساهمة
- الترخيص

---

### 2. QUICK_START.md (8.6 KB)
**الغرض:** دليل البدء السريع للمبتدئين

**الأقسام:**
- البدء
- تسجيل الدخول
- إنشاء صفحة منتج
- إدارة الطلبات
- فهم الإحصائيات
- استخدام لوحة الإدارة
- نصائح سريعة
- قياس النجاح

---

### 3. FEATURES.md (15.9 KB)
**الغرض:** قائمة تفصيلية بجميع الميزات

**الأقسام:**
- نظام المصادقة (9 ميزات)
- إنشاء وإدارة الصفحات (30+ ميزة)
- إدارة الطلبات (20+ ميزة)
- الإحصائيات والتحليلات (15+ ميزة)
- لوحة الإدارة (15+ ميزة)
- التصميم والواجهة (20+ ميزة)
- الأمان (5 ميزات)
- التخزين (10+ ميزة)
- وظائف إضافية (15+ ميزة)

**المجموع:** 50+ ميزة رئيسية

---

### 4. CHANGELOG.md (6.7 KB)
**الغرض:** سجل التغييرات والإصدارات

**محتوى:**
- الإصدار الحالي (1.0.0)
- جميع الميزات الجديدة
- الإصلاحات
- التحسينات
- الإصدارات المستقبلية المخططة

---

### 5. TROUBLESHOOTING.md (15.0 KB)
**الغرض:** دليل شامل لحل المشاكل

**الأقسام:**
- مشاكل تسجيل الدخول
- مشاكل الصفحات
- مشاكل الصور
- مشاكل الطلبات
- مشاكل الأداء
- مشاكل العرض
- مشاكل المتصفح
- مشاكل البيانات

**المجموع:** 20+ مشكلة شائعة مع حلولها

---

### 6. PROJECT_SUMMARY.md (11.3 KB)
**الغرض:** ملخص شامل للمشروع

**محتوى:**
- نظرة عامة سريعة
- حالة المشروع
- إحصائيات المشروع
- التصميم
- التقنيات
- أنواع المستخدمين
- الصفحات الرئيسية
- الميزات الرئيسية
- نقاط القوة
- القيود
- الخطط المستقبلية

---

### 7. DEPLOYMENT.md (10.9 KB)
**الغرض:** دليل نشر التطبيق

**محتوى:**
- 7 خيارات للنشر
- تكوينات إضافية
- SEO optimization
- PWA conversion
- اختبارات بعد النشر
- مشاكل شائعة
- مراقبة الأداء
- أمان إضافي

---

### 8. FILES_OVERVIEW.md (هذا الملف)
**الغرض:** نظرة عامة على جميع ملفات المشروع

---

## 📊 إحصائيات التفصيلية

### حسب النوع

| النوع | العدد | الحجم الإجمالي |
|------|-------|-----------------|
| HTML | 1 | 1.3 KB |
| CSS | 1 | 15.6 KB |
| JavaScript | 11 | 110.7 KB |
| Markdown (توثيق) | 8 | ~100 KB |
| **المجموع** | **21** | **~230 KB** |

### حسب الوظيفة

| الوظيفة | الملفات | النسبة |
|---------|---------|--------|
| الواجهة (UI) | 2 | 10% |
| المنطق (Logic) | 11 | 52% |
| التوثيق (Docs) | 8 | 38% |

### سطور الكود

| الملف | عدد الأسطر |
|------|-----------|
| index.html | ~35 |
| style.css | ~633 |
| app.js | ~60 |
| router.js | ~95 |
| utils.js | ~215 |
| storage.js | ~290 |
| auth.js | ~135 |
| components.js | ~410 |
| pages.js | ~585 |
| orders.js | ~200 |
| analytics.js | ~215 |
| admin.js | ~440 |
| pagebuilder.js | ~495 |
| **المجموع** | **~3,808** |

---

## 🎯 ترتيب التحميل

### في index.html

الملفات تُحمّل بهذا الترتيب:

1. **style.css** - الأنماط
2. **Font Awesome** - الأيقونات
3. **Google Fonts** - الخطوط
4. **utils.js** - الوظائف المساعدة
5. **auth.js** - المصادقة
6. **storage.js** - التخزين
7. **components.js** - المكونات
8. **pages.js** - الصفحات
9. **orders.js** - الطلبات
10. **analytics.js** - الإحصائيات
11. **admin.js** - الإدارة
12. **pagebuilder.js** - المحرر
13. **router.js** - التوجيه
14. **app.js** - التطبيق (أخيراً)

⚠️ **مهم:** الترتيب مهم! لا تغيّره.

---

## 🔗 الاعتمادات بين الملفات

```
app.js
  └── router.js
      ├── pages.js
      │   ├── components.js
      │   │   ├── auth.js
      │   │   │   └── storage.js
      │   │   │       └── utils.js
      │   │   └── utils.js
      │   ├── auth.js
      │   └── storage.js
      ├── pagebuilder.js
      │   ├── components.js
      │   ├── orders.js
      │   ├── storage.js
      │   └── utils.js
      ├── admin.js
      │   ├── components.js
      │   ├── analytics.js
      │   ├── storage.js
      │   └── utils.js
      └── analytics.js
          ├── storage.js
          └── utils.js
```

---

## 🚀 ملفات قابلة للتخصيص

### سهل التخصيص:

1. **CSS Variables** في `style.css`:
   ```css
   :root {
     --primary: #6366f1;
     --secondary: #ec4899;
     /* ... */
   }
   ```

2. **الألوان** - في بداية style.css
3. **النصوص** - في ملفات JS
4. **الحساب الافتراضي** - في storage.js
5. **Routes** - في router.js

### متوسط التخصيص:

1. **المكونات** - في components.js
2. **الصفحات** - في pages.js
3. **الأنماط** - في style.css

### متقدم:

1. **نظام التوجيه** - router.js
2. **التخزين** - storage.js
3. **المصادقة** - auth.js

---

## 📝 ملاحظات مهمة

### لا تحذف:

- ❌ utils.js - مطلوب لكل شيء
- ❌ storage.js - قلب التطبيق
- ❌ router.js - لا يعمل التطبيق بدونه
- ❌ components.js - تُستخدم في كل مكان

### يمكن تعديلها بحرية:

- ✅ style.css - غيّر الألوان والأنماط
- ✅ pages.js - عدّل النصوص
- ✅ components.js - خصّص المكونات

### ملفات اختيارية:

- 📚 جميع ملفات التوثيق (يُنصح بالاحتفاظ بها)

---

## 🔍 البحث السريع

### أين أجد...؟

**الألوان:**
- `css/style.css` → `:root` → CSS Variables

**النصوص:**
- العربية: في ملفات JS (pages.js, components.js)
- الإنجليزية: في comments

**الأزرار:**
- `css/style.css` → `.btn` classes

**النماذج:**
- `css/style.css` → `.form-` classes
- `js/pages.js` → render functions

**الإحصائيات:**
- `js/analytics.js` → جميع الوظائف

**الطلبات:**
- `js/orders.js` → جميع الوظائف
- `js/storage.js` → Order operations

**المصادقة:**
- `js/auth.js` → جميع الوظائف

---

## 💡 نصائح للتطوير

### عند إضافة ميزة جديدة:

1. **حدد الملف المناسب:**
   - UI → components.js
   - صفحة جديدة → pages.js
   - تخزين → storage.js
   - حسابات → analytics.js

2. **اتبع نمط الكود:**
   - استخدم نفس التنسيق
   - أضف تعليقات بالعربية
   - اختبر جيداً

3. **حدّث التوثيق:**
   - README.md
   - CHANGELOG.md
   - FEATURES.md

### عند إصلاح خطأ:

1. **افتح Console (F12)**
2. **حدد الملف والسطر**
3. **اقرأ الكود المحيط**
4. **اصلح واختبر**
5. **حدّث CHANGELOG.md**

---

<div align="center">

**🎉 الآن تعرف كل شيء عن ملفات المشروع!**

ابدأ التطوير بثقة! 💪

</div>